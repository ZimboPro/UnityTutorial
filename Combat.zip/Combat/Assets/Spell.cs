﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spell : MonoBehaviour {

    public Texture icon;
    public string name;
    public string description;
    public int id;
    public int damage;
    public int manaUsage;
    public float castTime;
    public bool followEnemy;
    public float speed;
    public float hitBox;
    public float direction;

    public GameObject target;

    // Use this for initialization
    void Start () {

	}
	
	// Update is called once per frame
	void Update () {
		if (this.followEnemy && target != null)
        {
            Vector3 targetPostion = new Vector3(target.transform.position.x, target.transform.position.y, target.transform.position.z);
            this.transform.LookAt(targetPostion);

            float distance = Vector3.Distance(target.transform.position, this.transform.position);
            if (distance > hitBox)
            {
                transform.Translate(Vector3.forward * speed * Time.deltaTime);
            }
            else
            {
                HitTarget();
            }
        }
        else
        {
            this.transform.Translate(Vector3.forward * speed * Time.deltaTime);
        }
	}

    void HitTarget()
    {
        Destroy(this.gameObject);
    }
}
