﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerScript : MonoBehaviour {
    public Rigidbody rb;

    public float forwardSpeed = 1000f;
    public float backwardSpeed = 500f;
    public float sideSpeed = 500f;

    public string rightKey = "d";
    public string leftKey = "a";
    public string forwardKey = "w";
    public string backKey = "s";

    public GameObject spellPrefab;

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void FixedUpdate()
    {
        if (Input.GetKey(rightKey))
        {
            rb.AddForce(sideSpeed * Time.deltaTime, 0, 0);
        }
        else if (Input.GetKey(leftKey))
        {
            rb.AddForce(-sideSpeed * Time.deltaTime, 0, 0);
        }
        else if (Input.GetKey(forwardKey))
        {
            rb.AddForce(0, 0, forwardSpeed * Time.deltaTime);
        }
        else if (Input.GetKey(backKey))
        {
            rb.AddForce(0, 0, -backwardSpeed * Time.deltaTime);
        }
    }

    private void castSpell()
    {
        Vector3 spellSpawnLocation = new Vector3(this.transform.position.x, this.transform.position.y, this.transform.position.z);

        GameObject clone;
        clone = Instantiate(spellPrefab, spellSpawnLocation, Quaternion.identity);
        
    }
}
