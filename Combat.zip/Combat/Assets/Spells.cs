﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spells {

    public Texture icon;
    public string name;
    public string description;
    public int id;
    public int damage;
    public int manaUsage;
    public float castTime;
    public bool followEnemy;

    public Spells(Spells spell)
    {
        icon = spell.icon;
        name = spell.name;
        description = spell.description;
        id = spell.id;
        damage = spell.damage;
        manaUsage = spell.manaUsage;
        castTime = spell.castTime;
        followEnemy = spell.followEnemy;
    }
}
