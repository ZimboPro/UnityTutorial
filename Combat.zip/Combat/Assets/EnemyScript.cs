﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyScript : MonoBehaviour {


    public Rigidbody rb;

    public float forwardSpeed = 1000f;
    public float backwardSpeed = 500f;
    public float leftSpeed = 500f;
    public float rightSpeed = 500f;

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
	}
}
